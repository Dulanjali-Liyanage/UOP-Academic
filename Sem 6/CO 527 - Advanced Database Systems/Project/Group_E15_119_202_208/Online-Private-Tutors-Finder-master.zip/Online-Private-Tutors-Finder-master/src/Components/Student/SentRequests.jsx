import React, { Component } from "react";
class SentRequests extends Component {
  state = {};
  render() {
    return <div></div>;
  }
}

export default SentRequests;
