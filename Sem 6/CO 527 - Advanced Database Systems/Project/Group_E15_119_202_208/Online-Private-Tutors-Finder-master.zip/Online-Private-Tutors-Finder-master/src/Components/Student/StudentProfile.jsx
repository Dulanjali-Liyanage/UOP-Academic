import React, { Component } from "react";
class StudentProfile extends Component {
  state = {};
  render() {
    return <div></div>;
  }
}

export default StudentProfile;
