import React, { Component } from "react";
import TutorSignIn from "./TutorSignIn";

export default class TutorHomePage extends Component {
  render() {
    return (
      <div>
        <TutorSignIn />
      </div>
    );
  }
}
