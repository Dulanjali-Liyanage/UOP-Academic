module.exports = {
  mongoURI:
    "mongodb+srv://roshani_d:rosh7@cluster0-pt6j9.mongodb.net/PrivateTutorDB?retryWrites=true&w=majority",
    secretOrKey: "secret"
};
