<html>
<body>
<?php
echo "hello world";
?>
</body>
</html>