<!DOCTYPE html>

<html>

<head>

<title>Project 1</title>

<meta name="viewport" content="width=device-width, initial-scale=1.0">


<style>


	*{
		
		box-sizing:border-box;
	
	}

	
	.header 					/*name of the class start with a fullstop*/

	{							
		
	
	}



	[class*="row"]::after

	{

		content:"";

		clear: both;

		display: table;

	}


	.row-1 {padding: 4px;}

	.row-2 {padding: 6px;}

	.row-3 {padding: 30px;}
	.row-4 {padding: 15px;}


	[class*="col"]

	{

		float: left;
		padding:0px;

	}

	.col-1 {width: 20%; text-align: center;}

	.col-2 {width: 13%; text-align: center;}

	.col-3 {width: 79%; text-align: left;}


</style>

</head>




<body background="Picture.jpg" style="background-size:100%;" >

<div class="header">

	<h1 style="color:Red;"><b><u>ORDER YOUR MEAL</u></b></h1>

	<h2 style="color:Blue;"><b>Fill out the form below and click "Order" to order</b></h2>


</div>




<div class="row-1">
	
	<div class="col-1">
		<b>First Name:</b>
		<div class="row-2"></div>
		<b>Last Name:</b>
		<div class="row-2"></div>
		<b>Apartment Number:</b>
		<div class="row-2"></div>
		<b>Street:</b>
		<div class="row-2"></div>
		<b>City:</b>
		<div class="row-2"></div>
		<b>Telephone Number:</b>
		<div class="row-2"></div>
		<b>Menu ID:</b>
	</div>
	<div class="col-3">
		<input type="text" name="first_name">
		<div class="row-1"></div>
		<input type="text" name="last_name">
		<div class="row-1"></div>
		<input type="text" name="apt_no">
		<div class="row-1"></div>
		<input type="text" name="street">
		<div class="row-1"></div>
		<input type="text" name="city">
		<div class="row-1"></div>
		<input type="text" name="telephone_no">
		<div class="row-1"></div>
		<input type="text" name="menu_id">
	</div>
</div>

<form action="form_message.php" method="post">




<div class="row-1">
	<div class="col-1">
		<div class="row-3"></div>
		<b>Your Comments:</b>
	</div>
	<div class="col-2">
		<textarea name="comments" id="comments" rows="10" cols="50">
		</textarea><br>
		<div class="row-2"></div>
		<input type="submit" value="Order" placeholder="Order" id="submit">
	</div>
</div>

</form>





























</body>




</html>
