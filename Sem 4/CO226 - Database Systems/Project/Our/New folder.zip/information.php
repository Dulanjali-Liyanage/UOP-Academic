<html>
<body>

<h1><b>Your Information System</b></h1>

Thank you, <?php echo $_POST["firstName"]?> for your perches from our web site<br><br>
your item colour is : <?php echo $_POST["colors"] ?> & T-Shirt size :<?php echo $_POST["x"] ?><br><br>
Selected items/items are:
<br><br>

<?php 

$answer = $_POST['itemA'];  
if ($answer == "cap") {          
    echo "*".'Cap';      
}
         
?>
<br><br>

<?php 

$answer = $_POST['itemB'];  
if ($answer == "wristband") {          
    echo "*".'Wrist band';      
}
         
?>
<br><br>

your items will be send to:<br><br>
<?php echo "<i>". $_POST["firstName"]."</i>"?> <?php echo "<i>".$_POST["lastName"]."</i>" ?>,<br>
<?php echo "<i>".$_POST["address1"]."</i>" ?>,<br>
<?php echo "<i>".$_POST["address2"]."</i>"?>,<br>
<?php echo "<i>".$_POST["address3"]."</i>"?><br><br>


 Thank you for submitting your comments.We appriciate it.You said<br><br>
 <?php
	echo "<i>". $_POST["yourComments"]."</i>"?>
</body>
</html>