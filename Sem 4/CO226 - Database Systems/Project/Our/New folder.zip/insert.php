<html>
<body>
<?php
   
   
   $server="localhost";
   $user="root";
   $pass="";
   $dname="projectnew";
   
   $con = new mysql($server,$user,$pass,$dname);
   
   if($con->connect_error)
   {
	   echo'Not Connected to server';
   }
   
   if (!mysqli_select_db($con,'projectnew'))
   {
	   echo 'database is not selecting';
   }
   
   $firstName =mysqli_real_escape_string($con, $_POST['fname']);
   $lastName = mysqli_real_escape_string($con,$_POST['lname'];
  
   $street = mysqli_real_escape_string($con,$_POST['addr'];
 

$sql="INSERT INTO Employee(firstName,lastName,street) VALUES ('$firstName','$lastName','$street')";

if(!mysqli_query($con,$sql))
{
	echo 'Not inserting';
}
else{
	echo 'Inserted';
}


?>
</body>
</html>