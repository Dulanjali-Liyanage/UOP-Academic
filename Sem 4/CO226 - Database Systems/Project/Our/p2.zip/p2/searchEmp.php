
<?php
echo "<body style =  'background: url(vintage-restaurant-background-vector-2015967.jpg);background-size:cover;'>";

?>
<?php
echo '<i style = "font-size:30px;font-family:calibri;">';
?>
<?php
/* Attempt MySQL server connection. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
$link = mysqli_connect("localhost", "root", "", "pty");

// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
   $name1 =$_GET['selecter'];


   $name2 =$_GET['search_by'];

// Attempt insert query execution
$sql = "SELECT * FROM Employee Where $name1 ='$name2'";


$result = $link-> query($sql);
if($result->num_rows > 0){
while($row = $result->fetch_assoc()){
echo"<br> ssn:".$row["Ssn"].
"  | First Name:".$row["FirstName"].
"  | Last Name:".$row["LastName"].
"  | Salary:".$row["Salary"].
"  | Birth Day:".$row["bDate"].
"  | Telephone:".$row["TelephoneNo"].
"  | Gender:".$row["Sex"].
"  | Apartment no:".$row["Apt_No"].
"  | Street:".$row["Street"].
"  | City:".$row["City"].
"  | Job Type:".$row["Job Type"].
"  | Worked Hours:".$row["WorkedHours"].
"<br> ";}
}



if(mysqli_query($link, $sql)){


} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}

// Close connection
mysqli_close($link);
?>